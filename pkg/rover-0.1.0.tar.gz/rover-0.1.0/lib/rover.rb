module Rover


  class Rover
    def self.class
      puts "classmethod"
    end

    def instance
      puts "instance method"
    end
  end

end

